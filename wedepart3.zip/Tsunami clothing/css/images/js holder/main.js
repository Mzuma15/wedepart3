// ============================================
// TSUNAMI CLOTHING — MAIN JAVASCRIPT FILE
// ============================================

// ---------- 1. HIGHLIGHT ACTIVE NAV LINK ----------
function highlightActiveNav() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        const linkPage = link.getAttribute('href');
        if (linkPage === currentPage) {
            link.classList.add('active');
        }
    });
}

// ---------- 2. MOBILE NAVIGATION TOGGLE ----------
function initMobileNav() {
    const header = document.querySelector('header');
    const nav = document.querySelector('nav');
    
    if (!header || !nav) return;
    
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'nav-toggle';
    toggleBtn.innerHTML = '☰';
    toggleBtn.setAttribute('aria-label', 'Toggle navigation');
    
    header.insertBefore(toggleBtn, nav);
    
    toggleBtn.addEventListener('click', () => {
        nav.classList.toggle('open');
        toggleBtn.innerHTML = nav.classList.contains('open') ? '✕' : '☰';
    });
}

// ---------- 3. CONTACT FORM VALIDATION ----------
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;
    
    const formMessage = document.getElementById('formMessage');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value.trim();
        
        formMessage.innerHTML = '';
        formMessage.style.color = '#e94560';
        
        if (!name) {
            formMessage.textContent = '❌ Please enter your full name.';
            return;
        }
        
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            formMessage.textContent = '❌ Please enter a valid email address.';
            return;
        }
        
        if (!subject) {
            formMessage.textContent = '❌ Please select a subject.';
            return;
        }
        
        if (message.length < 10) {
            formMessage.textContent = '❌ Message must be at least 10 characters.';
            return;
        }
        
        formMessage.style.color = '#28a745';
        formMessage.textContent = "✅ Thank you! Your message has been sent. We'll reply soon!";
        form.reset();
    });
}

// ---------- 4. GALLERY LIGHTBOX ----------
function initGalleryLightbox() {
    const galleryImages = document.querySelectorAll('.gallery-grid img');
    if (!galleryImages.length) return;
    
    const lightbox = document.createElement('div');
    lightbox.className = 'lightbox';
    lightbox.innerHTML = `
        <span class="lightbox-close">&times;</span>
        <img class="lightbox-img" src="" alt="Enlarged view">
    `;
    document.body.appendChild(lightbox);
    
    const lightboxImg = lightbox.querySelector('.lightbox-img');
    const closeBtn = lightbox.querySelector('.lightbox-close');
    
    galleryImages.forEach(img => {
        img.style.cursor = 'pointer';
        img.addEventListener('click', () => {
            lightboxImg.src = img.src;
            lightbox.classList.add('show');
        });
    });
    
    closeBtn.addEventListener('click', () => lightbox.classList.remove('show'));
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) lightbox.classList.remove('show');
    });
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') lightbox.classList.remove('show');
    });
}

// ---------- 5. SCROLL REVEAL ANIMATIONS ----------
function initScrollReveal() {
    const revealElements = document.querySelectorAll(
        '.service-card, .value-card, .about-block, .feature, .mission-box, .vision-box'
    );
    
    if (!revealElements.length) return;
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });
    
    revealElements.forEach(el => {
        el.classList.add('reveal');
        observer.observe(el);
    });
}

// ---------- 6. WELCOME TOAST ----------
function showWelcomeToast() {
    if (sessionStorage.getItem('tsunamiVisited')) return;
    
    const toast = document.createElement('div');
    toast.className = 'js-toast';
    toast.textContent = '👋 Welcome to Tsunami Clothing!';
    document.body.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 100);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 3500);
    
    sessionStorage.setItem('tsunamiVisited', 'true');
}

// ---------- 7. DYNAMIC FOOTER YEAR ----------
function updateFooterYear() {
    const footer = document.querySelector('footer p');
    if (footer) {
        const year = new Date().getFullYear();
        footer.innerHTML = footer.innerHTML.replace(/©\s*\d{4}/, `© ${year}`);
    }
}

// ---------- RUN EVERYTHING ON PAGE LOAD ----------
document.addEventListener('DOMContentLoaded', () => {
    highlightActiveNav();
    initMobileNav();
    initContactForm();
    initGalleryLightbox();
    initScrollReveal();
    updateFooterYear();
    showWelcomeToast();
});